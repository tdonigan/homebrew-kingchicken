To (re)generate the VIP materials in this directory do the following:

    $ ~/Development/SQUID/picard/tools/generate_vip.rb --delete-signed --rpmb-erase .

    $ python -m mbn_tools.sign \
        --root-ca-crt ~/Development/SQUID/picard/dev-certs/square_dev_root_ca.crt \
        --attest-ca-crt ~/Development/SQUID/picard/dev-certs/square_dev_attest_ca.crt \
        --local-attest-ca-key ~/Development/SQUID/picard/dev-certs/square_dev_attest_ca.key \
        --sa-hw-id 0x0090D0E153510242 \
        --sa-sw-id 0x0000000000000003 \
        --sa-debug 0x0000000000000002 \
        --sa-oem-id 0x5351 \
        --sa-model-id 0x0242 \
        unsigned_digest_table.mbn signed_digest_table.mbn

    $ rm unsigned_digest_table.mbn
